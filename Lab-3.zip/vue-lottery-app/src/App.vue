<script setup lang="ts">


import AppHeader from "@/components/AppHeader.vue";
</script>

<template>
<AppHeader></AppHeader>
<RouterView></RouterView>
</template>

<style scoped>

</style>