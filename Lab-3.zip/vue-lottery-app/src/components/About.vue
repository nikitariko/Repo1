<script setup lang="ts">

</script>

<template>
  <div class="wrapper">
    <h1>About page</h1>
    <div class="horizontal-line"></div>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus blanditiis commodi cum dolorem dolores et nostrum obcaecati provident rem temporibus! Alias aut, delectus dolore eveniet in molestias non obcaecati recusandae!</p>
  </div>
</template>

<style scoped>
.wrapper {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  margin-right: 20px;
  margin-left: 20px;
}
</style>