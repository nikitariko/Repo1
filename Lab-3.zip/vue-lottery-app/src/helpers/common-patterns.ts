export const emailPattern = new RegExp("");
export const uaPhoneNumberPattern = new RegExp("");